package kendaraan.util;

public interface Flyable {
    void fly();
}
